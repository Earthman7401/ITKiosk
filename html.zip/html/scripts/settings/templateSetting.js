var kioskTemplates = [
    'component.mainMenu',
	'component.classroom',
	'component.rollcall',
];