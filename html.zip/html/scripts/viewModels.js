﻿var viewModel = {
    "1": {
        // mainMenu
        "mainMenu": {

        },
		'classroom': {

        },
		'rollcall': {

        },
	},

    "2": {

        // mainMenu
        "mainMenu": {

        },
		'classroom': {

        },
		'rollcall': {

        },
    },
}